################################################################
#  _     ___ ___   ____   ___  _ _                             #
# | |   / _ \_ _| |___ \ / _ \/ / |                            #
# | |  | | | | |    __) | | | | | | LANDESOLYMPIADE INFORMATIK #
# | |__| |_| | |   / __/| |_| | | | 18./19. MÄRZ 2011, GÜSTROW #
# |_____\___/___| |_____|\___/|_|_|                            #
#                                                              #
# Aufgabe 4: Schiebepuzzle                                     #
################################################################


#--------------------------------------------------------------#
# dieser Code is vorgegeben - bitte nicht ändern

beispiel = [[2,3],[1,0]]

#--------------------------------------------------------------#

# Diese Funktionen müssen von Dir geschrieben werden.

def kombinationen(Zeilen,Spalten):
    return 0

def loese(Konfiguration):
    return []
