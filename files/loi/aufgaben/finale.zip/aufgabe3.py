################################################################
#  _     ___ ___   ____   ___  _ _                             #
# | |   / _ \_ _| |___ \ / _ \/ / |                            #
# | |  | | | | |    __) | | | | | | LANDESOLYMPIADE INFORMATIK #
# | |__| |_| | |   / __/| |_| | | | 18./19. MÄRZ 2011, GÜSTROW #
# |_____\___/___| |_____|\___/|_|_|                            #
#                                                              #
# Aufgabe 3: Prüfung einer Kreditkarte                         #
################################################################


#--------------------------------------------------------------#
# dieser Code is vorgegeben - bitte nicht ändern

nummer1 = 4417123456789113
nummer2 = 4417123456789114
nummer3 = 11111111111111111111111111
nummer4 = 0

#--------------------------------------------------------------#

# Diese Funktionen müssen von Dir geschrieben werden.

def pruefen(Zahl):
    return True

def generieren(Institut,Konto):
    return 0
