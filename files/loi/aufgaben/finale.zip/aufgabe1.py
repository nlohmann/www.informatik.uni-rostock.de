################################################################
#  _     ___ ___   ____   ___  _ _                             #
# | |   / _ \_ _| |___ \ / _ \/ / |                            #
# | |  | | | | |    __) | | | | | | LANDESOLYMPIADE INFORMATIK #
# | |__| |_| | |   / __/| |_| | | | 18./19. MÄRZ 2011, GÜSTROW #
# |_____\___/___| |_____|\___/|_|_|                            #
#                                                              #
# Aufgabe 1: Caesar-Verschlüsselung                            #
################################################################


#--------------------------------------------------------------#
# dieser Code is vorgegeben - bitte nicht ändern

text1 = 'DIESER TEXT IST GEHEIM'
text2 = 'HALLO! KANNST DU DAS LESEN?'
text3 = 'DQJULII DXI JDOOLHQ DE PRUJHQ'
text4 = '100 ZLOGVFKZHLQH IXHU REHOLA!'
text5 = 'FHCRE! QVRFRE GRKG JHEQR ZVG QRZ EBG-QERVMRUA-IRESNUERA IREFPUYHRFFRYG. QNORV JVEQ WRQRE OHPUFGNOR HZ QERVMRUA MRVPURA IREFPUBORA. QN QNF NYCUNORG FRPUFHAQMJNAMVT OHPUFGNORA UNG, XNAA RVA GRKG QHEPU MJRVSNPUR IREFPUYHRFFRYHAT RAGFPUYHRFFRYG JREQRA. NPU WN: QNF TRURVZJBEG VFG "XHPURA".'

#--------------------------------------------------------------#

# Diese Funktionen müssen von Dir geschrieben werden.

def verschluesseln(Text):
    return ""

def entschluesseln(Text):
    return ""

def neuesentschluesseln(Text):
    return ""
