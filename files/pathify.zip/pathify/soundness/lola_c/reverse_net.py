#!/usr/bin/env python

import sys

input_filename = sys.argv[1]
output_filemame = input_filename + ".reverse.lola"

input_net = open(input_filename, "r").readlines()
output_net = open(output_filemame, "w")

state = ""
cache_consuming = ""
cache_producing = ""

for line in input_net:
    if line.find("CONSUME") != -1:
        state = "CONSUMING"
        cache_consuming = ""
    if line.find("PRODUCE") != -1:
        state = "PRODUCING"
        cache_producing = ""
    if line.find("TRANSITION") != -1:
        state = "TRANSITION"
        output_net.write(cache_producing.replace("PRODUCE", "CONSUME"))
        output_net.write(cache_consuming.replace("CONSUME", "PRODUCE") + "\n\n")

        output_net.write(line)

    if state == "CONSUMING":
        cache_consuming += line

    if state == "PRODUCING":
        cache_producing += line

    if state == "":
        output_net.write(line)

    #print line
    #new_line = line.replace("CONSUME", "P!R!O!D!U!C!E").replace("PRODUCE", "CONSUME").replace("P!R!O!D!U!C!E", "PRODUCE")
    #output_net.write(new_line)

# flush caches
output_net.write(cache_producing.replace("PRODUCE", "CONSUME"))
output_net.write(cache_consuming.replace("CONSUME", "PRODUCE") + "\n\n")

output_net.close()
